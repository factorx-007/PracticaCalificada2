package com.example.PracticaC.controller;

public @interface Valid {
}
