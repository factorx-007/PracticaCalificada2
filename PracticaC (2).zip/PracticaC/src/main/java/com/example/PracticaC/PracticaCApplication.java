package com.example.PracticaC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticaCApplication {

	public static void main(String[] args) {
		SpringApplication.run(PracticaCApplication.class, args);
	}

}
